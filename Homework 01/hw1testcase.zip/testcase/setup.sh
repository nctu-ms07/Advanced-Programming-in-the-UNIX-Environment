#!/bin/bash

chmod +x launcher case3

ln -s /etc/passwd /tmp/testfile